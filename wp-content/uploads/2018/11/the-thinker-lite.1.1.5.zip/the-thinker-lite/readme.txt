= THE THINKER LITE =

* by Anariel Design, http://www.anarieldesign.com

- this theme is based on Underscores: http://underscores.me/
License: Distributed under the terms of the GNU GPL
Copyright: Automattic, automattic.com

The Thinker Lite is distributed under the terms of the GNU GPL

Images used in the theme screenshot are made by Anariel Design under the terms of the GNU GPL

Images on the screenshot.png are licensed under CCO Public Domain: - http://pixabay.com/it/ragazza-persone-paesaggio-sun-657753/, http://picjumbo.com/girl-writing-in-a-diary/